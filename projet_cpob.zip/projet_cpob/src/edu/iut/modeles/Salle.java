package edu.iut.modeles;

public class Salle {
	
	private String nom ; 
	
	public Salle() {
		this.nom = "specific" ; 
	}
	
	public Salle(String nom) {
		this.nom = nom ; 
	}

	public String getNom() {
		return nom;
	}
	
}
