package edu.iut.modeles;

public class Jour {

}
