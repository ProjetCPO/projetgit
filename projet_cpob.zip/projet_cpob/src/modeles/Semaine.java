package modeles;

public class Semaine {

}
